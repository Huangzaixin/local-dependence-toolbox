%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%       Type I local Kendall's tau surface        %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set width of the square local region: 0.05, 0.1, 0.2
quantile_interval = 0.05;

%% 1. empirical Type I local Kendall's tau surface
% read data
X = csvread('data/microsoft_u.csv',1,1);
Y = csvread('data/ibm_u.csv',1,1);

% or generate data from the copula model
data = copularnd("frank",7,50000);
X = data(:,1);
Y = data(:,2);

ldMatrix1 = fun_sampleldsurf_general(X,Y,measuretype,quantile_interval); hold on;


%% 2. copula model-based Type I theoretical local Kendall's tau surface
% copula parameters
weight1 = 0.406736925347243;                % weight of the first copula in the mixture copula model
weight2 = 0.168964114641286;                % weight of the second copula in the mixture copula model
copulaparameter1 = 0.299736317986873;       % for mixture copula, parameter of the first copula; for sjc copula, the upper tail dependence coefficient   
copulaparameter2 = 2.073496563664174;       % for mixture copula, parameter of the second copula; for sjc copula, the lower tail dependence coefficient 
copulaparameter3 = 1.926471919392572;       % parameter of the third copula in the mixture copula model
measuretype = 'Kendall';                    % Kendall's tau
copulatype = 'mixfgrg180';                  % copula type, see fun_ldcopula_type_II.m

ldMatrix2 = fun_copulaldsurf_general(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,measuretype,quantile_interval); hold on;  


%% lines
l = fun_copulald_general(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,'Kendall',0,quantile_interval,0,quantile_interval);
u = fun_copulald_general(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,'Kendall',1-quantile_interval,1,1-quantile_interval,1);

plot3([1,1],[1,5],[l,l],'--k');
plot3([1,1],[1,1],[l,0],'--k');
% plot3([10,10],[10,10],[u,u],'--k');


