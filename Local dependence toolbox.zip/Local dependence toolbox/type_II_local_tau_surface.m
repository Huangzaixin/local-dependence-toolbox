%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%       Type II local Kendall's tau surface       %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1. empirical Type II local Kendall's tau surface
measuretype = 'Kendall';                    
region_type = 'uu';  % "uu": upper-upper local Kendall's tau; "ll": lower-lower local Kendall's tau; "ul": upper-lower local Kendall's tau; "lu": lower-upper local Kendall's tau

U = csvread('data/microsoft_u.csv',1,1);
V = csvread('data/ibm_u.csv',1,1);

ldMatrix1 = fun_sampleldsurf_type_II(U,V,measuretype,region_type); hold on;


%% 2. copula model-based theoretical Type II local Kendall's tau surface
copulatype = 'mixfgrg180';                % copula type, see fun_ldcopula_type_II.m
weight1 = 0.406736925347243;              % weight of the first copula in the mixture copula
weight2 = 0.168964114641286;              % weight of the second copula in the mixture copula
copulaparameter1 = 0.299736317986873;     % for mixture copula, parameter of the first copula; for sjc copula, the upper tail dependence coefficient   
copulaparameter2 = 2.073496563664174;     % for mixture copula, parameter of the second copula; for sjc copula, the lower tail dependence coefficient 
copulaparameter3 = 1.926471919392572;     % parameter of the third copula in the mixture copula

ldMatrix2 = fun_copulaldsurf_type_II(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,measuretype,region_type);




