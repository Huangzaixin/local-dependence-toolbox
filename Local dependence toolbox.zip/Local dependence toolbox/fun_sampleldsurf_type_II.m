function [ldM] = fun_sampleldsurf_type_II(X,Y,measuretype,region)
% Description: Type II local Kendall's tau surface for sample data
% Inputs:  
%       1. X and Y: sample
%       2. measuretype: 
%          'Kendall' : local Kendall's tau
%       3. region: 
%          'UU': upper-upper region; 'UL': upper-lower region
%          'LU': lower-upper region; 'LL': lower-lower region   
% Output: ldM
%       1. ldM: Type II local Kendall's tau matrix
% Author: Zaixin Huang
% Any questions or bugs please contact me via eric.huangzaixin@gmail.com
% This version 2023.01.01. Latest version can be downloaded from https://github.com/Huangzaixin/local-dependence-toolbox
%% sample
Xtemp = X;
Ytemp = Y;

%% 
quantile_X = 0.05:0.05:0.95;
quantile_Y = 0.05:0.05:0.95;
        
for i=1:1:length(quantile_X)
    for j=1:1:length(quantile_Y)
        quantile_x = quantile_X(i);
        quantile_y = quantile_Y(j);
        LocalKendallMarix(i,j) = fun_sampleld_type_II(Xtemp,Ytemp,measuretype,region,quantile_x,quantile_y); 
        LocalKendallMarix(i,j);
    end
end

%% local Kendall's tau surface
surf(LocalKendallMarix);

xlabel('u','FontSize',13);
ylabel('v','FontSize',13);

switch lower(measuretype)
    case 'kendall'
         zlabel('empirical local Kendall''s tau','FontSize',13);     
    otherwise
       error('unknown measure type');
end 

%%
set(gcf,'color','w') 
set(gca,'FontSize',13);
zlim([0 1]); 
set(gcf,'unit','centimeters','position',[8 18 10 8]);

switch lower(region)
    case 'uu'
        view(-30,15);
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'XTickLabel',{'0.05',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.95'});
        set(gca,'YTickLabel',{'0.05',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.95'});   
    case 'ul'  
        view(150,15);
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'XTickLabel',{'0.95',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.05'});
        set(gca,'YTickLabel',{'0.95',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.05'});
    case 'lu'
        view(150,15);
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'XTickLabel',{'0.95',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.05'});
        set(gca,'YTickLabel',{'0.95',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.05'});
    case 'll'
        view(-30,15);
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'XTickLabel',{'0.05',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.95'});
        set(gca,'YTickLabel',{'0.05',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.95'});   
   otherwise
       error('unknown region.');
end 

disp('The program is running, please wait for a few seconds...');

ldM = LocalKendallMarix;



