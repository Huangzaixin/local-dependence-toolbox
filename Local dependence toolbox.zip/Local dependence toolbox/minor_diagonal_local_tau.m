%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Type II empirical and theoretical local Kendall's tau along the minor diagonal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1. empirical local Kendall's tau along the minor diagonal
% uniform (0,1) data after filtering by the AR(1)-GARCH(1,1)-student's t model
u = csvread('Data/ibm_u.csv',1,1); 
v = csvread('Data/microsoft_u.csv',1,1);
UV = [u v];
Xtemp = UV(:,1); 
Ytemp = UV(:,2); 

% compute local Kendall's tau at different quantiles
quantile_parameter = 0.05:0.01:0.5; 
for i=1:1:length(quantile_parameter)
       temp = find((UV(:,1)<=quantile(UV(:,1),quantile_parameter(i))&(UV(:,2)>=quantile(UV(:,2),1-quantile_parameter(i))))); 
       X = Xtemp(temp);
       Y = Ytemp(temp);
       if ~isempty(X) && ~isempty(Y)
          TAU = corr(X,Y,'type','Kendall');
          mainlocalKendallTau_l(i) = TAU;
       else
          mainlocalKendallTau_l(i) = 0;
       end 
end

plot(quantile_parameter,mainlocalKendallTau_l,'-o','MarkerSize',8,'LineWidth',1,'Color',[0 0 1]); hold on;

quantile_parameter_u = 0.5:0.01:0.95;
for i=1:1:length(quantile_parameter_u)
       temp = find((UV(:,1)>=quantile(UV(:,1),quantile_parameter_u(i))&(UV(:,2)<=quantile(UV(:,2),1-quantile_parameter_u(i))))); 
       X = Xtemp(temp);
       Y = Ytemp(temp); 
       if ~isempty(X) && ~isempty(Y)
          TAU = corr(X,Y,'type','Kendall');
          mainlocalKendallTau_u(i) = TAU;
       else
          mainlocalKendallTau_u(i) = 0;
       end
end

plot(quantile_parameter_u,mainlocalKendallTau_u,'-o','MarkerSize',8,'LineWidth',1,'Color',[0 0 1]); hold on;

y=[mainlocalKendallTau_l(46) mainlocalKendallTau_u(1)];
x=[0.5 0.5];
plot(x,y,'-','MarkerSize',10,'LineWidth',1,'Color',[0 0 1]); hold on;

% empirical global Kendall's tau
[empiricalglobalKendalltau,PVAL] = corr(Xtemp,Ytemp,'type','Kendall');
x=[0 1];
y=[empiricalglobalKendalltau empiricalglobalKendalltau];
plot(x,y,'-','MarkerSize',10,'LineWidth',2,'Color',[0 0 1]); hold on;


%% 2. copula model-based theoretical local Kendall's tau curve along the minor diagonal
% copula parameters
weight1 = 0.406736925347243;             % weight of the first copula
weight2 = 0.168964114641286;             % weight of the second copula
copulaparameter1 = 0.299736317986873;    % for mixture copula, parameter of the first copula; for sjc copula, the upper tail dependence coefficient   
copulaparameter2 = 2.073496563664174;    % for mixture copula, parameter of the second copula; for sjc copula, the lower tail dependence coefficient 
copulaparameter3 = 1.926471919392572;    % parameter of the third copula
measuretype = 'Kendall';                 % Kendall's tau
copulatype = 'mixfgrg180';               % copula type, see fun_ldcopula_type_II.m

% theoretical local Kendall's tau curve along the minor diagonal
quantile_parameter_l = 0.05:0.01:0.5;
for i=1:1:length(quantile_parameter_l)
       mainlocalKendallTau_l(i) = fun_copulald_type_II(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,'kendall','lu',quantile_parameter_l(i),1-quantile_parameter_l(i));
end
plot(quantile_parameter_l,mainlocalKendallTau_l,'-','MarkerSize',8,'LineWidth',3,'Color',[1 0 0]);hold on;

quantile_parameter_u = 0.5:0.01:0.95;
for j=1:1:length(quantile_parameter_u)
       mainlocalKendallTau_u(j) = fun_copulald_type_II(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,'kendall','ul',quantile_parameter_u(j),1-quantile_parameter_u(j));
end
plot(quantile_parameter_u,mainlocalKendallTau_u,'-','MarkerSize',8,'LineWidth',3,'Color',[1 0 0]);hold on;

y=[mainlocalKendallTau_l(46) mainlocalKendallTau_u(1)];
x=[0.5 0.5];
plot(x,y,'-','MarkerSize',10,'LineWidth',2,'Color',[1 0 0]);
hold on;

% theoretical global Kendall's tau
globalKendalltau = fun_copulald_type_II(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,'kendall','uu',0,0);

x=[0 1]; 
y=[globalKendalltau globalKendalltau]; 
plot(x,y,'-','MarkerSize',10,'LineWidth',2,'Color',[1 0 0]); 


