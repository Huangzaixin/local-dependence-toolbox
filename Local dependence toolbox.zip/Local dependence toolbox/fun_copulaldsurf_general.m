function [ldM] = fun_copulaldsurf_general(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,measuretype,quantile_interval)
% Description: Type I local Kendall's tau surface of the copula model
% Inputs: 
%      1. copulatype: see fun_ldcopula_general.m
%      2. weight1: weight of the first copula in the mixture copula
%         weight2: weight of the second copula in the mixture copula
%      3. copulaparameter1: parameter of the first copula 
%         copulaparameter2: parameter of the second copula
%         copulaparameter3: parameter of the third copula
%      4. measuretype: 
%         'kendall' : local Kendall's tau surface
%      5. quantile_interval: 
%         the width (or height) of the square local region
% Output: ldM
%      1. ldM: Type I local Kendall's tau matrix
% Author: Zaixin Huang
% Any questions or bugs please contact me via eric.huangzaixin@gmail.com
% This version 2023.01.01. Latest version can be downloaded from https://github.com/Huangzaixin/local-dependence-toolbox
%%
switch quantile_interval
    case 0.05
        quantile_upper = 0.95;
    case 0.1
        quantile_upper = 0.9;
    case 0.2
        quantile_upper = 0.8;
end

quantile_X = 0:quantile_interval:quantile_upper;
quantile_Y = 0:quantile_interval:quantile_upper;
        
for i=1:1:length(quantile_X) 
    for j=1:1:length(quantile_Y)
        if quantile_X(i) < 1 || quantile_Y(j) < 1
             temp_ld = ldcopula_general(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,measuretype,...,
                                           quantile_X(i),quantile_X(i) + quantile_interval,...,
                                           quantile_Y(j),quantile_Y(j) + quantile_interval);
             localdependence(i,j) = temp_ld;
        end
    end
end

surf(localdependence);  
% bar3(localdependence);
view(-30,30);

xlabel('u','FontSize',13); 
ylabel('v','FontSize',13);
set(gca,'FontSize',13);
set(gcf,'color','w') 
set(gcf,'unit','centimeters','position',[8 18 10 8]);

switch lower(measuretype)
    case 'kendall'
         zlabel('theoretical local Kendall''s ��','FontSize',12);        
    otherwise
       error(message('Unknown measure type.'));
end 

switch quantile_interval
    case 0.05
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21]);
        set(gca,'XTickLabel',{'0',' ',' ',' ','0.2',' ',' ',' ','0.4',' ',' ',' ','0.6',' ',' ',' ','0.8',' ',' ',' ','1'});
        set(gca,'YTickLabel',{'0',' ',' ',' ','0.2',' ',' ',' ','0.4',' ',' ',' ','0.6',' ',' ',' ','0.8',' ',' ',' ','1' });   
    case 0.1
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11]);
        set(gca,'XTickLabel',{'0',' ','0.2',' ','0.4',' ','0.6',' ','0.8',' ','1'});
        set(gca,'YTickLabel',{'0',' ','0.2',' ','0.4',' ','0.6',' ','0.8',' ','1' }); 
    case 0.2
        set(gca,'XTick',[1 2 3 4 5 6]);
        set(gca,'YTick',[1 2 3 4 5 6]);
        set(gca,'XTickLabel',{'0','0.2','0.4','0.6','0.8','1'});
        set(gca,'YTickLabel',{'0','0.2','0.4','0.6','0.8','1' });
end

ldM = localdependence;



