function [ld] = fun_sampleld_general(X,Y,type,pl,pu,ql,qu)
% Description: Type I local Kendall's tau for sample data
% Inputs:  
%       1. X and Y: sample data
%       2. type:
%          'Kendall' : local Kendall's tau
%       3. pl: lower bound of the quantile of X
%          pu: upper bound of the quantile of X   
%          ql: lower bound of the quantile of Y 
%          qu: upper bound of the quantile of Y   
% Output: ld
%       1. ld: Type I local Kendall's tau of sample in the selected region
% Author: Zaixin Huang
% Any questions or bugs please contact me via eric.huangzaixin@gmail.com
% This version 2023.01.01. Latest version can be downloaded from https://github.com/Huangzaixin/local-dependence-toolbox
%%
Z(:,1) = X;
Z(:,2) = Y;

temp = find( quantile(Z(:,1),pu) >= Z(:,1) & Z(:,1) > quantile(Z(:,1),pl) ...,
               & quantile(Z(:,2),qu) >= Z(:,2) & Z(:,2) > quantile(Z(:,2),ql)  ); 
 
Xtemp = X(temp);
Ytemp = Y(temp);

if isempty(Xtemp) || isempty(Ytemp)
    ld = 0;
    return;
end
        
switch lower(type)
    case 'kendall' 
        ld = corr(Xtemp,Ytemp,'type','Kendall'); 
    otherwise
        error('Error: unknown measure type.');
end


