%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% estimating local Kendall's tau and calculate its bootstrap standard error and 95% confidence interval %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% setting
options = optimset('Display','iter','TolCon',10^-12,'TolFun',10^-8,'TolX',10^-8);
lower = [0.01 0.01 0.01 1.01 1.01]; 
upper = [0.99 0.99 +Inf +Inf +Inf]; 
theta0 = [0.3 0.3 3 3 3]; 

% read data
u = csvread('Data/microsoft_u.csv',1,1); 
v = csvread('Data/ibm_u.csv',1,1); 
UV = [u v];

% parameters
copula_type = 'mixfgrg180';
weight1 = 0.406736925347243;            % weight of the first copula in the mixture copula model
weight2 = 0.168964114641286;            % weight of the second copula in the mixture copula model
copulaparameter1 = 0.299736317986873;   % for mixture copula, parameter of the first copula; for sjc copula, the upper tail dependence coefficient   
copulaparameter2 = 2.073496563664174;   % for mixture copula, parameter of the second copula; for sjc copula, the lower tail dependence coefficient 
copulaparameter3 = 1.926471919392572;   % parameter of the third copula in the mixture copula model
measuretype = 'Kendall';                % Kendall's tau
% ld_type_II = 'll';                    % "uu": upper-upper local Kendall's tau; "ll": lower-lower local Kendall's tau; "ul": upper-lower local Kendall's tau; "lu": lower-upper local Kendall's tau
% u_quantile = 0.1;
% v_quantile = 0.1;

% local region for generalized local Kendall's tau
ul_quantile = 0.4; 
uu_quantile = 0.6; 
vl_quantile = 0.4; 
vu_quantile = 0.6; 

%% estimating local Kendall's tau
% U-statistic-based estimator
% nonparametric_local_tau = fun_u_statistic_based_ld_type_II(UV,ld_type,u_quantile,v_quantile);
nonparametric_local_tau = fun_u_statistic_based_ld_general(UV,ul_quantile,uu_quantile,vl_quantile,vu_quantile);
% Copula model-based estimator
% copula_based_local_tau = fun_copulald_type_II(copula_type,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,'kendall',ld_type,0.05,0.05);
copula_based_local_tau = fun_copulald_general(copula_type,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,measuretype,ul_quantile,uu_quantile,vl_quantile,vu_quantile);

%% calculate bootstrap standard error and 95% confidence interval
% start bootstrap: 1000 times
B_times = 1000;
b_nonparametric_local_tau = zeros(B_times,1);
b_copula_par = zeros(B_times,5);
b_copula_based_local_tau = zeros(B_times,1);
b_matrix_index = bootstrp(B_times,@(x)x,[1:1:2266]);
    
for b_index = 1:1:B_times
    % generate bootstrap sample
    temp_bootsample_UV = UV(b_matrix_index(b_index,:),:);
    
    % U-statistic-based estimator
    % b_nonparametric_local_tau(b_index,1) = fun_u_statistic_based_ld_type_II(temp_bootsample_UV,ld_type,u_quantile,v_quantile);
    b_nonparametric_local_tau(b_index,1) = fun_u_statistic_based_ld_general(temp_bootsample_UV,ul_quantile,uu_quantile,vl_quantile,vu_quantile);
        
    % copula model-based estimator
    [parameters LL] = fmincon('frankgumbelrotgumbel180CL',theta0,[],[],[],[],lower,upper,[],options,[temp_bootsample_UV(:,1),temp_bootsample_UV(:,2)]);
    temp_weight1 = parameters(1);
    temp_weight2 = parameters(2);
    temp_copulaparameter1 = parameters(3);
    temp_copulaparameter2 = parameters(4);
    temp_copulaparameter3 = parameters(5);
 
    % b_copula_based_local_tau(b_index,1) = fun_copulald_type_II(copula_type,temp_weight1,temp_weight2,temp_copulaparameter1,temp_copulaparameter2,temp_copulaparameter3,measuretype,ld_type,u_quantile,v_quantile);
    b_copula_based_local_tau(b_index,1) = fun_copulald_general(copula_type,temp_weight1,temp_weight2,temp_copulaparameter1,temp_copulaparameter2,temp_copulaparameter3,measuretype,ul_quantile,uu_quantile,vl_quantile,vu_quantile);
    
    disp("current index:" + b_index);
end
    
%% bootstrap standard error and 95% confidence interval
% for copula model-based estimator
mean_b_copula_based = mean(b_copula_based_local_tau);
% standard error
se_copula_based = sqrt(sum((b_copula_based_local_tau(:,1) - mean_b_copula_based).^2)./(B_times - 1));
% 95% confidence interval
b_conf_interval_95_copula_based_lower = copula_based_local_tau - 1.96 * se_copula_based;
b_conf_interval_95_copula_based_upper = copula_based_local_tau + 1.96 * se_copula_based;  

% for U-statistic-based estimator
mean_b_nonparametric = mean(b_nonparametric_local_tau);
% standard error
se_nonparametric = sqrt(sum((b_nonparametric_local_tau(:,1) - mean_b_nonparametric).^2)./(B_times - 1));
% 95% confidence interval
b_conf_interval_95_nonparametric_lower = nonparametric_local_tau - 1.96 * se_nonparametric;
b_conf_interval_95_nonparametric_upper = nonparametric_local_tau + 1.96 * se_nonparametric;



