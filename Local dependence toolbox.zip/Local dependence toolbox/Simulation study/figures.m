%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%          figures for the simulation results          %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% region 1 
%% region 1  standard errors
plot(regin1SE(:,1),'--o','Color',[0.00,0.00,1.00],'LineWidth',1,'MarkerSize',7.2); hold on;
plot(regin1SE(:,2),'-o','Color',[0.81,0.15,0.15],'LineWidth',2.5,'MarkerSize',7.2); hold on;

plot(regin1SE(:,3),'--x','Color',[0.00,0.00,1.00],'LineWidth',1,'MarkerSize',7.5); hold on;
plot(regin1SE(:,4),'-x','Color',[0.81,0.15,0.15],'LineWidth',2.5,'MarkerSize',7.5); hold on;

plot(regin1SE(:,5),'--^','Color',[0.00,0.00,1.00],'LineWidth',1,'MarkerSize',6.7); hold on;
plot(regin1SE(:,6),'-^','Color',[0.81,0.15,0.15],'LineWidth',2.5,'MarkerSize',6.7); hold on;

plot([1 5],[95 95],'-.','Color',[0,0,0],'LineWidth',1.5);

ylim([0 0.5])
set(gca,'YTick',[0 0.1 0.2 0.3 0.4 0.5]);
set(gca,'Xticklabel',[100 200 500 1000 2000]);
set(gcf,'unit','centimeters','position',[15 15 9 9])
set(gca,'Position', [.125 .17 .80 .74]);
set(gca,'lineWidth', 1);
legend('U-statistic, Clayton(u,v,1)','Copula model, Clayton(u,v,1)','U-statistic, Clayton(u,v,2)','Copula model, Clayton(u,v,2)','U-statistic, Clayton(u,v,4)','Copula model, Clayton(u,v,4)','fontsize',11.5,'Location','northwest','EdgeColor',[1 1 1])

xlabel('Region I   SE_{e} (Clayton copula)','fontsize',13.5) 
set(gca,'FontSize',13.5)
set(gcf, 'color', [1 1 1])

%% region 1  coverage probabilities
plot(regin1CP(:,1),'--o','Color',[0.00,0.00,1.00],'LineWidth',1,'MarkerSize',7.2); hold on;
plot(regin1CP(:,2),'-o','Color',[0.81,0.15,0.15],'LineWidth',2.5,'MarkerSize',7.2); hold on;

plot(regin1CP(:,3),'--x','Color',[0.00,0.00,1.00],'LineWidth',1,'MarkerSize',7.5); hold on;
plot(regin1CP(:,4),'-x','Color',[0.81,0.15,0.15],'LineWidth',2.5,'MarkerSize',7.5); hold on;

plot(regin1CP(:,5),'--^','Color',[0.00,0.00,1.00],'LineWidth',1,'MarkerSize',6.7); hold on;
plot(regin1CP(:,6),'-^','Color',[0.81,0.15,0.15],'LineWidth',2.5,'MarkerSize',6.7); hold on;
plot([1 5],[95 95],'-.','Color',[0,0,0],'LineWidth',2.5);

ylim([0 100])
set(gca,'YTick',[0 20 40 60 80 100]);
set(gca,'Xticklabel',[100 200 500 1000 2000]);
set(gcf,'unit','centimeters','position',[15 15 9 9]) 
set(gca,'Position', [.125 .17 .80 .74]);
set(gca,'lineWidth', 1);
legend('U-statistic, Clayton(u,v,1)','Copula model, Clayton(u,v,1)','U-statistic, Clayton(u,v,2)','Copula model, Clayton(u,v,2)','U-statistic, Clayton(u,v,4)','Copula model, Clayton(u,v,4)','CP=95%','fontsize',11.5,'Location','southwest','EdgeColor',[1 1 1])

xlabel('Region I   CP% (Clayton copula)','fontsize',13.5) 
set(gca,'FontSize',13.5)
set(gcf, 'color', [1 1 1])




