% estimate copula model
function copula_par = fun_copula_estimation(copulatype,data)
options = optimset('Display','off','TolCon',10^-12,'TolFun',10^-9,'TolX',10^-9);
u = data(:,1);
v = data(:,2);
    switch copulatype
        case 'clayton'
            lower = 0.001;
            theta0 = 1.001;
            [copula_par] = fmincon('claytonCL',theta0,[],[],[],[],lower,[],[],options,[u,v]);
        case 'gumbel'
            lower = 1.001;
            theta0 = 2;
            [copula_par] = fmincon('gumbelCL',theta0,[],[],[],[],lower,[],[],options,[u,v]);
        case 'frank'
            lower = 0.001;
            theta0 = 1;
            [copula_par] = fmincon('frankCL',theta0,[],[],[],[],lower,[],[],options,[u,v]);   
    end
end