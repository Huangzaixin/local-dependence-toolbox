function [ldM] = fun_copulaldsurf_type_II(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,measuretype,region)
% Description: Type II local Kendall's tau surface of the copula model
% Inputs: 
%      1. copulatype: see fun_ldcopula_type_II.m
%      2. weight1: weight of the first copula in the mixture copula
%         weight2: weight of the second copula in the mixture copula
%      3. copulaparameter1: parameter of the first copula
%         copulaparameter2: parameter of the second copula
%         copulaparameter3: parameter of the third copula
%      4. measuretype:
%         'kendall': local Kendall's tau surface
%      5. region:
%         'UU': upper-upper region; 'UL': upper-lower region;
%         'LU': lower-upper region; 'LL': lower-lower region;
% Output: ldM
%      1. ldM: local Kendall's tau matrix in the selected region
% Author: Zaixin Huang
% Any questions or bugs please contact me via eric.huangzaixin@gmail.com
% This version 2023.01.01. Latest version can be downloaded from https://github.com/Huangzaixin/local-dependence-toolbox
%%
quantile_X = 0.05:0.05:0.95;
quantile_Y = 0.05:0.05:0.95;
      
for i=1:1:length(quantile_X)
    for j=1:1:length(quantile_Y)
        localdependence(i,j) = fun_ldcopula_type_II(copulatype,weight1,weight2,copulaparameter1,copulaparameter2,copulaparameter3,measuretype,region,quantile_X(i),quantile_Y(j));            
    end
end

surf(localdependence);
xlabel('u','FontSize',13);
ylabel('v','FontSize',13);
set(gcf,'color','w');
set(gca,'FontSize',13);
zlim([0 1]);
set(gcf,'unit','centimeters','position',[8 18 10 8]);

%%
switch lower(region)
    case 'uu'        
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'XTickLabel',{'0.05',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.95'});
        set(gca,'YTickLabel',{'0.05',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.95'});   
     
        switch lower(measuretype)
            case 'kendall'
                 zlabel('upper-upper local Kendall''s �� surface','FontSize',13);        
        otherwise
           error(message('unknown measure type.'));
        end 
        
    case 'ul'     
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'XTickLabel',{'0.95',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.05'});
        set(gca,'YTickLabel',{'0.95',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.05'});
    
        switch lower(measuretype) 
            case 'kendall'
                 zlabel('upper-lower local Kendall''s �� surface','FontSize',13);        
        otherwise
           error(message('unknown measure type.'));
        end 
        
    case 'lu'      
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'XTickLabel',{'0.95',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.05'});
        set(gca,'YTickLabel',{'0.95',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.05'});
    
        switch lower(measuretype)
            case 'kendall'
                 zlabel('lower-upper local Kendall''s �� surface','FontSize',13);        
        otherwise
           error(message('unknown measure type.'));
        end 
    
    case 'll'        
        set(gca,'XTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'YTick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19]);
        set(gca,'XTickLabel',{'0.05',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.95'});
        set(gca,'YTickLabel',{'0.05',' ',' ',' ',' ',' ','0.35',' ',' ',' ',' ',' ','0.65',' ',' ',' ',' ',' ','0.95'});   
    
        switch lower(measuretype)
            case 'kendall'
                 zlabel('lower-lower local Kendall''s �� surface','FontSize',13);        
            otherwise
               error(message('unknown measure type.'));
        end 
    
    otherwise
       error('unknown selected region.');
end 

disp('The program is running, please wait for a few seconds...');

ldM = localdependence;




