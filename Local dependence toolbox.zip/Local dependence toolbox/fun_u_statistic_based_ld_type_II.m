function ld = fun_u_statistic_based_ld_type_II(data,ld_type,X,Y)
% Description: Type II local Kendall's tau based on U-statistic
% Inputs:
%      1. data: sample data
%      2. ld_type: 
%         'll': lower-lower local Kendall's tau; 'uu': upper-upper local Kendall's tau
%      3. X: for 'll', the upper bound of the first variable
%            for 'uu', the lower bound of the first variable
%      4. Y: for 'll', the upper bound of the second variable
%            for 'uu', the lower bound of the second variable
% Author: Zaixin Huang
% Email: eric.huangzaixin@gmail.com
% Version: 2023.01.01. Latest version can be downloaded from https://github.com/Huangzaixin/local-dependence-toolbox
%%
    d_X = data(:,1);
    d_Y = data(:,2);
    sum = 0;
    M = 0;   % number of observation pairs in the selected region  
    
    switch ld_type
        case "uu"
            for i=1:1:length(d_X)-1
                for j=i+1:1:length(d_X)
                    sum = sum + sign((d_X(i)-d_X(j)).*(d_Y(i)-d_Y(j))).*(d_X(i) >= X & d_X(j) >= X & d_Y(i) >= Y & d_Y(j) >= Y);
                    M = M + (d_X(i) >= X & d_X(j) >= X & d_Y(i) >= Y & d_Y(j) >= Y);
                end
            end
        case "ll"
            for i=1:1:length(d_X)-1
                for j=i+1:1:length(d_X)
                    sum = sum + sign((d_X(i)-d_X(j)).*(d_Y(i)-d_Y(j))).*(X >= d_X(i) & X >= d_X(j) & Y >= d_Y(i) & Y >= d_Y(j));
                    M = M + (X >= d_X(i) & X >= d_X(j) & Y >= d_Y(i) & Y >= d_Y(j));
                end
            end
    end
         
    ld = sum/M;   
end



