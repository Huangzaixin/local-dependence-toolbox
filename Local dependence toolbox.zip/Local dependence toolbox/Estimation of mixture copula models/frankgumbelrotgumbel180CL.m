function CL = frankgumbelrotgumbel180CL(theta,data)
u = data(:,1);
v = data(:,2);
w1 = theta(1);      % weight of frank copula 
w2 = theta(2);      % weight of gumbel copula 
alpha1 = theta(3);  % frank copula parameter
alpha2 = theta(4);  % gumbel copula parameter
alpha3 = theta(5);  % rotated gumbel copula parameter (180-degrees)

CL = -sum(log((w2.*exp(-((-log(u)).^alpha2 + (-log(v)).^alpha2).^(1./alpha2)).*(-log(u)).^(alpha2 - 1).*(-log(v)).^(alpha2 - 1).*((-log(u)).^alpha2 + (-log(v)).^alpha2).^(2./alpha2 - 2))./(u.*v) - (alpha1.*w1.*exp(-alpha1.*u).*exp(-alpha1.*v))./((exp(-alpha1) - 1).*(((exp(-alpha1.*u) - 1).*(exp(-alpha1.*v) - 1))./(exp(-alpha1) - 1) + 1)) - ((exp(-((-log(1 - u)).^alpha3 + (-log(1 - v)).^alpha3).^(1./alpha3)).*(-log(1 - u)).^(alpha3 - 1).*(-log(1 - v)).^(alpha3 - 1).*((-log(1 - u)).^alpha3 + (-log(1 - v)).^alpha3).^(2./alpha3 - 2))./((u - 1).*(v - 1)) - (alpha3.*exp(-((-log(1 - u)).^alpha3 + (-log(1 - v)).^alpha3).^(1./alpha3)).*(-log(1 - u)).^(alpha3 - 1).*(-log(1 - v)).^(alpha3 - 1).*(1./alpha3 - 1).*((-log(1 - u)).^alpha3 + (-log(1 - v)).^alpha3).^(1./alpha3 - 2))./((u - 1).*(v - 1))).*(w1 + w2 - 1) + (alpha1.*w1.*exp(-alpha1.*u).*exp(-alpha1.*v).*(exp(-alpha1.*u) - 1).*(exp(-alpha1.*v) - 1))./((exp(-alpha1) - 1).^2.*(((exp(-alpha1.*u) - 1).*(exp(-alpha1.*v) - 1))./(exp(-alpha1) - 1) + 1).^2) - (alpha2.*w2.*exp(-((-log(u)).^alpha2 + (-log(v)).^alpha2).^(1./alpha2)).*(-log(u)).^(alpha2 - 1).*(-log(v)).^(alpha2 - 1).*(1./alpha2 - 1).*((-log(u)).^alpha2 + (-log(v)).^alpha2).^(1./alpha2 - 2))./(u.*v)));
