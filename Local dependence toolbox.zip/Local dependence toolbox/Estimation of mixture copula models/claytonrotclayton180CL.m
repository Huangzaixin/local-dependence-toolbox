function CL = claytonrotclayton180CL(theta,data)
u = data(:,1);
v = data(:,2);
w1 = theta(1);   % weight of clayton copula
alpha1 = theta(2);   % clayton copula parameter
alpha2 = theta(3);   % rotated clayton copula parameter (180 degree)

CL = -sum(log((alpha1.*w1.*(1./alpha1 + 1))./(u.^(alpha1 + 1).*v.^(alpha1 + 1).*(1./u.^alpha1 + 1./v.^alpha1 - 1).^(1./alpha1 + 2)) - (alpha2.*(1./alpha2 + 1).*(w1 - 1))./((1 - u).^(alpha2 + 1).*(1 - v).^(alpha2 + 1).*(1./(1 - u).^alpha2 + 1./(1 - v).^alpha2 - 1).^(1./alpha2 + 2))));