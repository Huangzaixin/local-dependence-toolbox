function CL = gumbelrotgumbel180CL(theta,data)
u = data(:,1);
v = data(:,2);
w1 = theta(1);   % weight of gumbel copula
alpha1 = theta(2);  % gumbel copula parameter
alpha2 = theta(3);  % rotated gumbel copula parameter

CL = -sum(log((w1.*exp(-((-log(u)).^alpha1 + (-log(v)).^alpha1).^(1./alpha1)).*(-log(u)).^(alpha1 - 1).*(-log(v)).^(alpha1 - 1).*((-log(u)).^alpha1 + (-log(v)).^alpha1).^(2./alpha1 - 2))./(u.*v) - ((exp(-((-log(1 - u)).^alpha2 + (-log(1 - v)).^alpha2).^(1./alpha2)).*(-log(1 - u)).^(alpha2 - 1).*(-log(1 - v)).^(alpha2 - 1).*((-log(1 - u)).^alpha2 + (-log(1 - v)).^alpha2).^(2./alpha2 - 2))./((u - 1).*(v - 1)) - (alpha2.*exp(-((-log(1 - u)).^alpha2 + (-log(1 - v)).^alpha2).^(1./alpha2)).*(-log(1 - u)).^(alpha2 - 1).*(-log(1 - v)).^(alpha2 - 1).*(1./alpha2 - 1).*((-log(1 - u)).^alpha2 + (-log(1 - v)).^alpha2).^(1./alpha2 - 2))./((u - 1).*(v - 1))).*(w1 - 1) - (alpha1.*w1.*exp(-((-log(u)).^alpha1 + (-log(v)).^alpha1).^(1./alpha1)).*(-log(u)).^(alpha1 - 1).*(-log(v)).^(alpha1 - 1).*(1./alpha1 - 1).*((-log(u)).^alpha1 + (-log(v)).^alpha1).^(1./alpha1 - 2))./(u.*v)));

