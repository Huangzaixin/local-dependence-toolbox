#################################################################################################
# Generating random data for Archimedean mixture copula models
# Author: Zaixin Huang
# Email: eric.huangzaixin@gmail.com
# This version 2023.01.01. 
# Latest version can be downloaded from https://github.com/Huangzaixin/local-dependence-toolbox
#################################################################################################
require(copula)

randomNumber = 10000;  # number of random data

#################################################
# MixGC copula : Gumbel copula + Clayton copula 
#################################################
mC <- mixCopula(list(gumbelCopula(1.4195617, dim=2),
                     claytonCopula(0.2352401, dim=2) ),
                     c(3536870,10000000-3536870)/10000000)  # the weight of mixture copula
# set.seed(10) 
rndcopula <- rCopula(randomNumber, mC)


######################################################################################################
# MixrG180rC180 copula : rotated Gumbel copula (180-degrees) + rotated Clayton copula (180-degrees) 
######################################################################################################
mC <- mixCopula(list(rotCopula(gumbelCopula(1.2689573, dim=2), flip = c(TRUE,TRUE)),
                     rotCopula(claytonCopula(1.1025806, dim=2), flip = c(TRUE,TRUE))),
                     c(7326773,10000000-7326773)/10000000)
rndcopula <- rCopula(randomNumber, mC)


##########################################################################
# MixGrG180 copula : Gumbel copula + rotated Gumbel copula (180-degrees)
##########################################################################
mC <- mixCopula(list(gumbelCopula(1.5318942, dim=2),
                     rotCopula(gumbelCopula(1.2173659, dim=2), flip = c(TRUE,TRUE)) ),
                     c(3139547,10000000-3139547)/10000000)
rndcopula <- rCopula(randomNumber, mC)


###########################################################################
# MixCrC180 copula : Clayton copula + rotated Clayton copula (180-degrees)
###########################################################################
mC <- mixCopula(list(claytonCopula(1.140215, dim=2),
                     rotCopula(claytonCopula(1.457104, dim=2), flip = c(TRUE,TRUE)) ),
                     c(5189100,10000000-5189100)/10000000)
rndcopula <- rCopula(randomNumber, mC)





