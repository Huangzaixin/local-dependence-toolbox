%% estimation of mixture copula models
break;
clear;
format long;
options = optimset('Display','iter','TolCon',10^-12,'TolFun',10^-8,'TolX',10^-8);

%% read data
u = csvread('../data/microsoft_u.csv',1,1);  
v = csvread('../data/ibm_u.csv',1,1); 

%% Clayton copula
lower = 0.01;   % lower bound 
theta0 = 1.01;  % starting values
[parameter,LL] = fmincon('claytonCL',theta0,[],[],[],[],lower,[],[],options,[u,v]);
AIC = -2*(-LL) + 2;
AIC

%% Rotated Clayton copula (180-degrees)
lower = 0.01;
theta0 = 1.1;
[parameter LL] = fmincon('claytonCL',theta0,[],[],[],[],lower,[],[],options,1-[u,v]);
AIC = -2*(-LL) + 2;
AIC

%% Gumbel copula
lower = 1.01;
theta0 = 2;
[parameter LL] = fmincon('gumbelCL',theta0,[],[],[],[],lower,[],[],options,[u,v]);
AIC = -2*(-LL) + 2;
AIC

%% Rotated Gumbel copula (180-degrees)
lower = 1.01;
theta0 = 2;
[parameter LL] = fmincon('gumbelCL',theta0,[],[],[],[],lower,[],[],options,1-[u,v]);
AIC = -2*(-LL) + 2;
AIC

%% MixGC copula : Gumbel copula + Clayton copula
lower = [0.01 1.01 0.01];   % lower bound 
upper = [0.99 +Inf +Inf];   % upper bound 
theta0 = [0.5 2 1];     % starting values
[parameters LL] = fmincon('gumbelclaytonCL',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
AIC = -2*(-LL) + 2;
AIC

%% MixrGrC copula : rotated Gumbel copula + rotated Clayton copula
lower = [0.01 1.01 0.01];
upper = [0.99 +Inf +Inf];
theta0 = [0.5 2 1];
[parameters LL] = fmincon('rotgumbel180rotclayton180CL',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
AIC = -2*(-LL) + 2;
AIC

%% MixGrG180 copula : Gumbel copula + rotated Gumbel copula (180-degrees)
lower = [0.01 1.01 1.01];
upper = [0.99 +Inf +Inf];
theta0 = [0.3 3 3];
[parameters LL] = fmincon('gumbelrotgumbel180CL',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
AIC = -2*(-LL) + 2;
AIC

%% MixCrC180 copula : Clayton copula + rotated Clayton copula (180-degrees)
lower = [0.01 1.01 1.01];
upper = [0.99 +Inf +Inf];
theta0 = [0.5 3 3];
[parameters LL] = fmincon('claytonrotclayton180CL',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
AIC = -2*(-LL) + 2;
AIC

%% MixfGrG180 copula : Frank copula + Gumbel copula + rotated Gumbel copula (180-degrees)
lower = [0.01 0.01 0.01 1.01 1.01];
upper = [0.99 0.99 +Inf +Inf +Inf];
theta0 = [0.3 0.3 3 3 3];
[parameters LL] = fmincon('frankgumbelrotgumbel180CL',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
AIC = -2*(-LL) + 2;
AIC

%% SJC copula
lower = 1e-12*ones(2,1);	
upper = 1-1e-12*ones(2,1);  
tauU = 0.3;
tauL = 0.6;
theta0 = [tauU;tauL];	 
[parameters LL] = fmincon('sym_jc_CL',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
parameters;
AIC = -2 * -LL + 2*2;

% generating data from the SJC copula
T = 100000;
data = sym_jc_rnd(tauU,tauL,T);	


