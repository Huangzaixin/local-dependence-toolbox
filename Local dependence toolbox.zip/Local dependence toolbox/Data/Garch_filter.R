###################################################################################################
# Author: Zaixin Huang
# Email: eric.huangzaixin@gmail.com
# This version 2023.01.01. 
# The latest version can be downloaded from https://github.com/Huangzaixin/local-dependence-toolbox
###################################################################################################
library(rugarch) 
library(tseries)
library(vars)
library(FinTS) 
library(moments)
library(dgof) 

# read data
rate <- read.csv("data.csv",header = T)

Microsoft <- as.matrix(rate[4])
temp <- Microsoft[2:length(Microsoft)]

IBM <- as.matrix(rate[5])
temp <- IBM[2:length(IBM)]

# summary
summary(temp)
sd(temp)
skewness(temp)
kurtosis(temp)

# ADF test
adf.test(temp)

# J-B test
jarque.bera.test(temp)

# Ljung-Box test
Box.test(temp,lag = 1, type="Ljung")
Box.test(temp,lag = 2, type="Ljung") 
Box.test(temp,lag = 3, type="Ljung") 
Box.test(temp,lag = 4, type="Ljung") 
Box.test(temp,lag = 5, type="Ljung") 

# ARCH test
ArchTest(as.matrix(temp),lags = 1)
ArchTest(as.matrix(temp),lags = 2)
ArchTest(as.matrix(temp),lags = 3)
ArchTest(as.matrix(temp),lags = 4)
ArchTest(as.matrix(temp),lags = 5)

# GARCH(1,0) model 
garch_spec = ugarchspec(mean.model = list(armaOrder = c(1,0), include.mean = F), 
                        variance.model = list(model = "sGARCH", garchOrder = c(1,1)),
                        distribution.model = "std") 
fit = ugarchfit(spec = garch_spec, data = temp)
fit

# standardized residual
z <- residuals(fit,standardize = TRUE)

# Ljung-Box test again
Box.test(z,lag = 1, type="Ljung")
Box.test(z,lag = 2, type="Ljung") 
Box.test(z,lag = 3, type="Ljung")
Box.test(z,lag = 4, type="Ljung") 
Box.test(z,lag = 5, type="Ljung")

# ARCH test again
ArchTest(as.matrix(z),lags = 1)
ArchTest(as.matrix(z),lags = 2)
ArchTest(as.matrix(z),lags = 3)
ArchTest(as.matrix(z),lags = 4)
ArchTest(as.matrix(z),lags = 5) 

# probability integral transformation
u <- pdist("std",z, mu = 0, sigma = 1, shape=coef(fit)["shape"])

# save data
write.csv(u,"microsoft_u.csv") 
write.csv(u,"ibm_u.csv")




