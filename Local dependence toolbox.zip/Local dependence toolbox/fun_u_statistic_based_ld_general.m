function ld = fun_u_statistic_based_ld_general(data,Xl,Xu,Yl,Yu)
% Description: Type I local Kendall's tau based on U-statistic
% Inputs: 
%      1. data: sample data
%      2. Xl: lower bound of X
%         Xu: upper bound of X
%         Yl: lower bound of Y
%         Yu: upper bound of Y
% Author: Zaixin Huang
% Email: eric.huangzaixin@gmail.com
% Version: 2023.01.01. Latest version can be downloaded from https://github.com/Huangzaixin/local-dependence-toolbox
%%
    d_X = data(:,1);
    d_Y = data(:,2);     
    sum = 0;
    M = 0;  % number of observation pairs in the selected region  
    
    for i=1:1:length(d_X)-1
        for j=i+1:1:length(d_X)
            sum = sum + sign((d_X(i) - d_X(j)).*(d_Y(i) - d_Y(j))).*(Xu >= d_X(i) & d_X(i) >= Xl & Xu >= d_X(j) & d_X(j) >= Xl & Yu >= d_Y(i) & d_Y(i) >= Yl & Yu >= d_Y(j) & d_Y(j) >= Yl);
            M = M + (Xu >= d_X(i) & d_X(i) >= Xl & Xu >= d_X(j) & d_X(j) >= Xl & Yu >= d_Y(i) & d_Y(i) >= Yl & Yu >= d_Y(j) & d_Y(j) >= Yl);
        end
    end
            
    ld = sum/M;   
end



